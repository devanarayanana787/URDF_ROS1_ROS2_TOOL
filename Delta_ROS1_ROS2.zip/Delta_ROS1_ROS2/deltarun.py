#!/usr/bin/env python3
import os
import sys
import shutil
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QFileDialog, QLabel, QProgressBar, QMessageBox, QHBoxLayout
)
from PyQt6.QtGui import QPixmap
from PyQt6.QtCore import Qt

class ROS1ToROS2Converter(QWidget):
    def __init__(self):
        super().__init__()
        self.ros2_files_path = None  # User will select this dynamically
        self.ros1_package_path = None
        self.initUI()

    def initUI(self):
        self.setWindowTitle("ROS 1 to ROS 2 Package Converter")
        self.setGeometry(100, 100, 500, 350)
        self.setStyleSheet("background-color: #1a1a1a; color: #ff6600; font-size: 14px;")

        layout = QVBoxLayout()

        # Logo Placement
        logo_layout = QHBoxLayout()
        self.left_logo_label = QLabel()
        left_pixmap = QPixmap("sld_to_urdf.jpeg")
        self.left_logo_label.setPixmap(left_pixmap.scaled(80, 80, Qt.AspectRatioMode.KeepAspectRatio))
        logo_layout.addWidget(self.left_logo_label)

        logo_layout.addStretch()

        self.right_logo_label = QLabel()
        right_pixmap = QPixmap("logowithname.jpeg")
        self.right_logo_label.setPixmap(right_pixmap.scaled(120, 50, Qt.AspectRatioMode.KeepAspectRatio))
        logo_layout.addWidget(self.right_logo_label)

        layout.addLayout(logo_layout)

        # Select ROS 2 Files Folder
        self.ros2_label = QLabel("Select ROS 2 Files Folder:")
        layout.addWidget(self.ros2_label)

        self.ros2_btn = QPushButton("Select source folder")
        self.ros2_btn.setStyleSheet("background-color: #ff6600; color: black;")
        self.ros2_btn.clicked.connect(self.select_ros2_folder)
        layout.addWidget(self.ros2_btn)

        # Select ROS 1 Package Folder
        self.ros1_label = QLabel("Select ROS 1 Package Folder:")
        layout.addWidget(self.ros1_label)

        self.upload_btn = QPushButton("Upload ROS 1 Package")
        self.upload_btn.setStyleSheet("background-color: #ff6600; color: black;")
        self.upload_btn.clicked.connect(self.upload_package)
        layout.addWidget(self.upload_btn)

        self.progress_bar = QProgressBar()
        layout.addWidget(self.progress_bar)

        # Convert Button
        self.convert_btn = QPushButton("Convert to ROS 2")
        self.convert_btn.setStyleSheet("background-color: #ff6600; color: black;")
        self.convert_btn.clicked.connect(self.convert_package)
        self.convert_btn.setEnabled(False)
        layout.addWidget(self.convert_btn)

        self.setLayout(layout)

    def select_ros2_folder(self):
        """Allow the user to select the folder containing ROS 2 files (CMakeLists.txt, package.xml, etc.)"""
        folder_path = QFileDialog.getExistingDirectory(self, "Select ROS 2 Files Folder")
        if folder_path:
            self.ros2_files_path = folder_path
            self.ros2_label.setText(f"Selected ROS 2 Folder: {os.path.basename(folder_path)}")

    def upload_package(self):
        """Allow the user to select the ROS 1 package folder."""
        folder_path = QFileDialog.getExistingDirectory(self, "Select ROS 1 Package Folder")
        if folder_path:
            self.ros1_package_path = folder_path
            self.ros1_label.setText(f"Selected: {os.path.basename(folder_path)}")
            if self.ros2_files_path:  # Enable convert button only if both folders are selected
                self.convert_btn.setEnabled(True)

    def convert_package(self):
        """Convert the selected ROS 1 package to ROS 2."""
        if not self.ros1_package_path or not self.ros2_files_path:
            QMessageBox.warning(self, "Error", "Please select both the ROS 1 package and ROS 2 files folder.")
            return

        self.progress_bar.setValue(20)

        if not self.swap_files():
            QMessageBox.warning(self, "Error", "Missing required files in ROS 2 folder!")
            return

        self.progress_bar.setValue(60)
        self.add_display_launch()
        self.replace_package_name()
        self.progress_bar.setValue(100)
        QMessageBox.information(self, "Success", "Package converted successfully!")

    def swap_files(self):
        """Copy ROS 2 template files (CMakeLists.txt, package.xml) to the ROS 1 package."""
        try:
            ros2_cmake = os.path.join(self.ros2_files_path, "CMakeLists.txt")
            ros2_package = os.path.join(self.ros2_files_path, "package.xml")

            if not os.path.exists(ros2_cmake) or not os.path.exists(ros2_package):
                return False  # Required files are missing

            shutil.copy(ros2_cmake, os.path.join(self.ros1_package_path, "CMakeLists.txt"))
            shutil.copy(ros2_package, os.path.join(self.ros1_package_path, "package.xml"))
            return True
        except Exception as e:
            QMessageBox.warning(self, "Error", f"File copy failed: {e}")
            return False

    def add_display_launch(self):
        """Add a display.launch.xml file to the ROS 1 package's launch directory."""
        try:
            launch_folder = os.path.join(self.ros1_package_path, "launch")
            os.makedirs(launch_folder, exist_ok=True)
            display_launch = os.path.join(self.ros2_files_path, "display.launch.xml")

            if os.path.exists(display_launch):
                shutil.copy(display_launch, os.path.join(launch_folder, "display.launch.xml"))
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to add launch file: {e}")

    def replace_package_name(self):
        """Replace 'your_package_name' in copied files with the actual package name."""
        try:
            package_name = os.path.basename(self.ros1_package_path)
            files_to_update = [
                os.path.join(self.ros1_package_path, "package.xml"),
                os.path.join(self.ros1_package_path, "CMakeLists.txt"),
                os.path.join(self.ros1_package_path, "launch", "display.launch.xml"),
            ]

            for file_path in files_to_update:
                if os.path.exists(file_path):
                    with open(file_path, 'r') as file:
                        content = file.read()
                    content = content.replace("your_package_name", package_name)
                    with open(file_path, 'w') as file:
                        file.write(content)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to update package names: {e}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    converter = ROS1ToROS2Converter()
    converter.show()
    sys.exit(app.exec())

