dont change any items in the source folder as it is the root directory for the whole package ...


open the Delta_ROS1_ROS2 folder on your favourite code editor and then run the deltarun.py file and select the source direcotry as the souce_folder and then click the folder of the ros 1 package which is generated form the solidworks file and also donot touch the deltarun.py


open the terminal and install pyqt6 as it is the gui interface without it throws error ... for windows install pyqt6 by --- pip


dont use it without permission and redistribution as it is liscened Apache-2.0


developed by


Delta Automations    

 
Devanarayanan A 
Agnivesh KT


contact 8921210873 india
contact 9188372187 india
